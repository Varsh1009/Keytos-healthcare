MADE-UP sample data for NeuroTrail. Not a real person. Built by data/samples/make_apple_sample.py
